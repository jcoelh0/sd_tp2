package entities.Manager.Interfaces;

/**
 *
 * @author andre e joao
 */
public interface IManagerOW {

	/**
	 *
	 * @param id
	 * @return
	 */
	public boolean phoneCustomer(int id);
}
